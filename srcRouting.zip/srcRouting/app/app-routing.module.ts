import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChildComponent } from './child/child.component';
import { NavigateComponent } from './navigate/navigate.component';


const routes: Routes = [
  {path : 'subject' , component : ChildComponent},
  { path : 'select' , component: NavigateComponent}
  // {path : '**' , component : ChildComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
