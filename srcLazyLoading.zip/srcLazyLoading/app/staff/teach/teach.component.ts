import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teach',
  templateUrl: './teach.component.html',
  styleUrls: ['./teach.component.css']
})
export class TeachComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
