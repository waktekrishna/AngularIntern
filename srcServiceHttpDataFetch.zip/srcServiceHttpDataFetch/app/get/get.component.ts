import { Component, OnInit } from '@angular/core';
import { DemoService } from '../demo.service';

@Component({
  selector: 'app-get',
  templateUrl: './get.component.html',
  styleUrls: ['./get.component.css']
})
export class GetComponent implements OnInit {

  public Data:any = []

  constructor( private _demoservice : DemoService) { }

  ngOnInit(): void {
    // this.Data = this._demoservice.getData

    this._demoservice.getData().subscribe(data=>this.Data=data)
  }

}
