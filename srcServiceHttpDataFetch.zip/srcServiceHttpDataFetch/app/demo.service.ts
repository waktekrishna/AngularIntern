import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable, observable } from 'rxjs';
import { IDetails } from './details';

@Injectable({
  providedIn: 'root'
})
export class DemoService {
  get: any;

  constructor( private http : HttpClient) { }

  private _url : string = '/assets/Data/data.json'

getData() : Observable<IDetails[]>
{
  return this.http.get<IDetails[]>(this._url);
}

}
