import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GetComponent } from './get/get.component';
import { Get2Component } from './get2/get2.component';

const routes: Routes = [
  {
    path: "Get" , component : GetComponent
  },
  {
    path: 'Get2' , component: Get2Component
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
