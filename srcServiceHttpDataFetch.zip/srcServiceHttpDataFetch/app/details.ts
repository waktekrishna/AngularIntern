export interface IDetails{
    "Subject" : string,
    "Marks" : string

}