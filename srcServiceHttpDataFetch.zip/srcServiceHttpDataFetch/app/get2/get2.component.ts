import { Component, OnInit } from '@angular/core';
import { DemoService } from '../demo.service';

@Component({
  selector: 'app-get2',
  templateUrl: './get2.component.html',
  styleUrls: ['./get2.component.css']
})
export class Get2Component implements OnInit {

  public Data: any = []

  constructor( private _demoservice : DemoService) { }

  ngOnInit(): void {
    // this.Data = this._demoservice.getData()

    this._demoservice.getData().subscribe(data=>this.Data=data)
  }

}
